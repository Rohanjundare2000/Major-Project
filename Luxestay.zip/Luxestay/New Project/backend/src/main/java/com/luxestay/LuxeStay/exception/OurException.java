package com.luxestay.LuxeStay.exception;

public class OurException extends RuntimeException {

    public OurException(String message) {
        super(message);
    }
}
